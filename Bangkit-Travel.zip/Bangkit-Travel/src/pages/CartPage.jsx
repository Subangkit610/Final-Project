import React, { useEffect, useState } from "react";
import axios from "axios";

const CartPage = () => {
  const [cartItems, setCartItems] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [loading, setLoading] = useState(true);

  const apiKey = "24405e01-fbc1-45a5-9f5a-be13afcd757c";

  // Ambil data cart
  const fetchCart = async () => {
    try {
      const response = await axios.get(
        "https://travel-journal-api-bootcamp.do.dibimbing.id/api/v1/carts",
        {
          headers: { apiKey },
        }
      );
      setCartItems(response.data.data);
    } catch (error) {
      console.error("Gagal mengambil data cart:", error);
    } finally {
      setLoading(false);
    }
  };

  // Ambil metode pembayaran
  const fetchPaymentMethods = async () => {
    try {
      const response = await axios.get(
        "https://travel-journal-api-bootcamp.do.dibimbing.id/api/v1/payment-methods",
        {
          headers: { apiKey },
        }
      );
      setPaymentMethods(response.data.data);
    } catch (error) {
      console.error("Gagal mengambil metode pembayaran:", error);
    }
  };

  useEffect(() => {
    fetchCart();
    fetchPaymentMethods();
  }, []);

  const totalPrice = cartItems.reduce(
    (total, item) => total + item.total_price,
    0
  );

  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
          Keranjang Belanja
        </h1>

        {loading ? (
          <p className="text-center text-gray-500">Memuat data...</p>
        ) : cartItems.length === 0 ? (
          <p className="text-center text-gray-500">Keranjang kamu masih kosong.</p>
        ) : (
          <>
            {/* List Cart */}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-lg shadow-md p-4 flex flex-col gap-2"
                >
                  <img
                    src={item.activity.imageUrls[0]}
                    alt={item.activity.title}
                    className="w-full h-48 object-cover rounded-md"
                  />
                  <h2 className="text-lg font-semibold">{item.activity.title}</h2>
                  <p className="text-gray-600 text-sm">{item.activity.province}</p>
                  <p className="text-gray-700">
                    Jumlah: <strong>{item.quantity}</strong>
                  </p>
                  <p className="text-blue-600 font-bold">
                    Rp{item.total_price.toLocaleString("id-ID")}
                  </p>
                </div>
              ))}
            </div>

            {/* Total Harga */}
            <div className="mt-8 text-center">
              <h2 className="text-xl font-bold text-gray-800 mb-2">
                Total Harga: Rp{totalPrice.toLocaleString("id-ID")}
              </h2>
            </div>

            {/* Metode Pembayaran */}
            <div className="mt-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 text-center">
                Metode Pembayaran
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className="bg-white p-4 shadow rounded-lg text-center border hover:border-yellow-400 transition"
                  >
                    <img
                      src={method.imageUrl}
                      alt={method.name}
                      className="w-20 h-14 object-contain mx-auto mb-2"
                    />
                    <p className="font-medium text-gray-700">{method.name}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CartPage;
